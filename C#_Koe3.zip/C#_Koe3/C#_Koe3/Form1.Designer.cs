﻿namespace C__Koe3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPizza1 = new System.Windows.Forms.Label();
            this.numUpDownPizza1 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza2 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza3 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza4 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza5 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza6 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza7 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza8 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza9 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza10 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet10 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet9 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet8 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet7 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet6 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet5 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet4 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet3 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet2 = new System.Windows.Forms.NumericUpDown();
            this.numUpDownLisataytteet1 = new System.Windows.Forms.NumericUpDown();
            this.lblValitsePizzat = new System.Windows.Forms.Label();
            this.lblValitseLisataytteet = new System.Windows.Forms.Label();
            this.lblValitseJuomat = new System.Windows.Forms.Label();
            this.lblPizza2 = new System.Windows.Forms.Label();
            this.lblPizza3 = new System.Windows.Forms.Label();
            this.lblPizza4 = new System.Windows.Forms.Label();
            this.lblPizza5 = new System.Windows.Forms.Label();
            this.lblPizza6 = new System.Windows.Forms.Label();
            this.lblPizza7 = new System.Windows.Forms.Label();
            this.lblPizza8 = new System.Windows.Forms.Label();
            this.lblPizza9 = new System.Windows.Forms.Label();
            this.lblPizza10 = new System.Windows.Forms.Label();
            this.txtTulostus = new System.Windows.Forms.TextBox();
            this.btnLaske = new System.Windows.Forms.Button();
            this.btnTyhjenna = new System.Windows.Forms.Button();
            this.btnKassa = new System.Windows.Forms.Button();
            this.txtKassaTulostus = new System.Windows.Forms.TextBox();
            this.lblTulostus = new System.Windows.Forms.Label();
            this.lblKassaTulostus = new System.Windows.Forms.Label();
            this.numUpDown05L = new System.Windows.Forms.NumericUpDown();
            this.numUpDown15L = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMuutaHintoja = new System.Windows.Forms.Button();
            this.lblPizza1Uusi = new System.Windows.Forms.Label();
            this.numUpDownPizza1Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza2Uusi = new System.Windows.Forms.NumericUpDown();
            this.lblPizza2Uusi = new System.Windows.Forms.Label();
            this.lblPizza3Uusi = new System.Windows.Forms.Label();
            this.lblPizza4Uusi = new System.Windows.Forms.Label();
            this.lblPizza5Uusi = new System.Windows.Forms.Label();
            this.lblPizza6Uusi = new System.Windows.Forms.Label();
            this.lblPizza7Uusi = new System.Windows.Forms.Label();
            this.lblPizza8Uusi = new System.Windows.Forms.Label();
            this.lblPizza9Uusi = new System.Windows.Forms.Label();
            this.lblPizza10Uusi = new System.Windows.Forms.Label();
            this.numUpDownPizza3Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza4Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza5Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza6Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza7Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza8Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza9Uusi = new System.Windows.Forms.NumericUpDown();
            this.numUpDownPizza10Uusi = new System.Windows.Forms.NumericUpDown();
            this.btnTallennaUudetHinnat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown05L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown15L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza1Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza2Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza3Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza4Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza5Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza6Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza7Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza8Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza9Uusi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza10Uusi)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPizza1
            // 
            this.lblPizza1.AutoSize = true;
            this.lblPizza1.Location = new System.Drawing.Point(23, 63);
            this.lblPizza1.Name = "lblPizza1";
            this.lblPizza1.Size = new System.Drawing.Size(100, 13);
            this.lblPizza1.TabIndex = 0;
            this.lblPizza1.Text = "Pepperoni (10,00 €)";
            // 
            // numUpDownPizza1
            // 
            this.numUpDownPizza1.Location = new System.Drawing.Point(138, 63);
            this.numUpDownPizza1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza1.Name = "numUpDownPizza1";
            this.numUpDownPizza1.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza1.TabIndex = 1;
            // 
            // numUpDownPizza2
            // 
            this.numUpDownPizza2.Location = new System.Drawing.Point(138, 89);
            this.numUpDownPizza2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza2.Name = "numUpDownPizza2";
            this.numUpDownPizza2.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza2.TabIndex = 3;
            // 
            // numUpDownPizza3
            // 
            this.numUpDownPizza3.Location = new System.Drawing.Point(138, 115);
            this.numUpDownPizza3.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza3.Name = "numUpDownPizza3";
            this.numUpDownPizza3.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza3.TabIndex = 5;
            // 
            // numUpDownPizza4
            // 
            this.numUpDownPizza4.Location = new System.Drawing.Point(138, 141);
            this.numUpDownPizza4.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza4.Name = "numUpDownPizza4";
            this.numUpDownPizza4.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza4.TabIndex = 7;
            // 
            // numUpDownPizza5
            // 
            this.numUpDownPizza5.Location = new System.Drawing.Point(138, 167);
            this.numUpDownPizza5.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza5.Name = "numUpDownPizza5";
            this.numUpDownPizza5.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza5.TabIndex = 9;
            // 
            // numUpDownPizza6
            // 
            this.numUpDownPizza6.Location = new System.Drawing.Point(138, 193);
            this.numUpDownPizza6.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza6.Name = "numUpDownPizza6";
            this.numUpDownPizza6.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza6.TabIndex = 11;
            // 
            // numUpDownPizza7
            // 
            this.numUpDownPizza7.Location = new System.Drawing.Point(138, 219);
            this.numUpDownPizza7.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza7.Name = "numUpDownPizza7";
            this.numUpDownPizza7.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza7.TabIndex = 13;
            // 
            // numUpDownPizza8
            // 
            this.numUpDownPizza8.Location = new System.Drawing.Point(138, 245);
            this.numUpDownPizza8.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza8.Name = "numUpDownPizza8";
            this.numUpDownPizza8.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza8.TabIndex = 15;
            // 
            // numUpDownPizza9
            // 
            this.numUpDownPizza9.Location = new System.Drawing.Point(138, 271);
            this.numUpDownPizza9.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza9.Name = "numUpDownPizza9";
            this.numUpDownPizza9.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza9.TabIndex = 17;
            // 
            // numUpDownPizza10
            // 
            this.numUpDownPizza10.Location = new System.Drawing.Point(138, 297);
            this.numUpDownPizza10.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDownPizza10.Name = "numUpDownPizza10";
            this.numUpDownPizza10.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza10.TabIndex = 19;
            // 
            // numUpDownLisataytteet10
            // 
            this.numUpDownLisataytteet10.Location = new System.Drawing.Point(209, 297);
            this.numUpDownLisataytteet10.Name = "numUpDownLisataytteet10";
            this.numUpDownLisataytteet10.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet10.TabIndex = 39;
            // 
            // numUpDownLisataytteet9
            // 
            this.numUpDownLisataytteet9.Location = new System.Drawing.Point(209, 271);
            this.numUpDownLisataytteet9.Name = "numUpDownLisataytteet9";
            this.numUpDownLisataytteet9.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet9.TabIndex = 37;
            // 
            // numUpDownLisataytteet8
            // 
            this.numUpDownLisataytteet8.Location = new System.Drawing.Point(209, 245);
            this.numUpDownLisataytteet8.Name = "numUpDownLisataytteet8";
            this.numUpDownLisataytteet8.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet8.TabIndex = 35;
            // 
            // numUpDownLisataytteet7
            // 
            this.numUpDownLisataytteet7.Location = new System.Drawing.Point(209, 219);
            this.numUpDownLisataytteet7.Name = "numUpDownLisataytteet7";
            this.numUpDownLisataytteet7.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet7.TabIndex = 33;
            // 
            // numUpDownLisataytteet6
            // 
            this.numUpDownLisataytteet6.Location = new System.Drawing.Point(209, 193);
            this.numUpDownLisataytteet6.Name = "numUpDownLisataytteet6";
            this.numUpDownLisataytteet6.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet6.TabIndex = 31;
            // 
            // numUpDownLisataytteet5
            // 
            this.numUpDownLisataytteet5.Location = new System.Drawing.Point(209, 167);
            this.numUpDownLisataytteet5.Name = "numUpDownLisataytteet5";
            this.numUpDownLisataytteet5.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet5.TabIndex = 29;
            // 
            // numUpDownLisataytteet4
            // 
            this.numUpDownLisataytteet4.Location = new System.Drawing.Point(209, 141);
            this.numUpDownLisataytteet4.Name = "numUpDownLisataytteet4";
            this.numUpDownLisataytteet4.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet4.TabIndex = 27;
            // 
            // numUpDownLisataytteet3
            // 
            this.numUpDownLisataytteet3.Location = new System.Drawing.Point(209, 115);
            this.numUpDownLisataytteet3.Name = "numUpDownLisataytteet3";
            this.numUpDownLisataytteet3.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet3.TabIndex = 25;
            // 
            // numUpDownLisataytteet2
            // 
            this.numUpDownLisataytteet2.Location = new System.Drawing.Point(209, 89);
            this.numUpDownLisataytteet2.Name = "numUpDownLisataytteet2";
            this.numUpDownLisataytteet2.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet2.TabIndex = 23;
            // 
            // numUpDownLisataytteet1
            // 
            this.numUpDownLisataytteet1.Location = new System.Drawing.Point(209, 63);
            this.numUpDownLisataytteet1.Name = "numUpDownLisataytteet1";
            this.numUpDownLisataytteet1.Size = new System.Drawing.Size(102, 20);
            this.numUpDownLisataytteet1.TabIndex = 21;
            // 
            // lblValitsePizzat
            // 
            this.lblValitsePizzat.AutoSize = true;
            this.lblValitsePizzat.Location = new System.Drawing.Point(23, 20);
            this.lblValitsePizzat.Name = "lblValitsePizzat";
            this.lblValitsePizzat.Size = new System.Drawing.Size(111, 13);
            this.lblValitsePizzat.TabIndex = 40;
            this.lblValitsePizzat.Text = "Valitse pizzat (max 10)";
            // 
            // lblValitseLisataytteet
            // 
            this.lblValitseLisataytteet.AutoSize = true;
            this.lblValitseLisataytteet.Location = new System.Drawing.Point(206, 20);
            this.lblValitseLisataytteet.Name = "lblValitseLisataytteet";
            this.lblValitseLisataytteet.Size = new System.Drawing.Size(134, 26);
            this.lblValitseLisataytteet.TabIndex = 41;
            this.lblValitseLisataytteet.Text = "Valitse lisätäytteiden määrä\r\n(1,50 € per täyte)";
            // 
            // lblValitseJuomat
            // 
            this.lblValitseJuomat.AutoSize = true;
            this.lblValitseJuomat.Location = new System.Drawing.Point(346, 20);
            this.lblValitseJuomat.Name = "lblValitseJuomat";
            this.lblValitseJuomat.Size = new System.Drawing.Size(72, 13);
            this.lblValitseJuomat.TabIndex = 43;
            this.lblValitseJuomat.Text = "Valitse juomat";
            // 
            // lblPizza2
            // 
            this.lblPizza2.AutoSize = true;
            this.lblPizza2.Location = new System.Drawing.Point(23, 89);
            this.lblPizza2.Name = "lblPizza2";
            this.lblPizza2.Size = new System.Drawing.Size(84, 13);
            this.lblPizza2.TabIndex = 46;
            this.lblPizza2.Text = "Havaiji (10,00 €)";
            // 
            // lblPizza3
            // 
            this.lblPizza3.AutoSize = true;
            this.lblPizza3.Location = new System.Drawing.Point(23, 115);
            this.lblPizza3.Name = "lblPizza3";
            this.lblPizza3.Size = new System.Drawing.Size(107, 13);
            this.lblPizza3.TabIndex = 47;
            this.lblPizza3.Text = "Capricciosa (10,00 €)";
            // 
            // lblPizza4
            // 
            this.lblPizza4.AutoSize = true;
            this.lblPizza4.Location = new System.Drawing.Point(23, 141);
            this.lblPizza4.Name = "lblPizza4";
            this.lblPizza4.Size = new System.Drawing.Size(102, 13);
            this.lblPizza4.TabIndex = 48;
            this.lblPizza4.Text = "Margherita (10,00 €)";
            // 
            // lblPizza5
            // 
            this.lblPizza5.AutoSize = true;
            this.lblPizza5.Location = new System.Drawing.Point(23, 167);
            this.lblPizza5.Name = "lblPizza5";
            this.lblPizza5.Size = new System.Drawing.Size(83, 13);
            this.lblPizza5.TabIndex = 49;
            this.lblPizza5.Text = "Kebab (10,00 €)";
            // 
            // lblPizza6
            // 
            this.lblPizza6.AutoSize = true;
            this.lblPizza6.Location = new System.Drawing.Point(23, 193);
            this.lblPizza6.Name = "lblPizza6";
            this.lblPizza6.Size = new System.Drawing.Size(98, 13);
            this.lblPizza6.TabIndex = 50;
            this.lblPizza6.Text = "Mexicana (10,00 €)";
            // 
            // lblPizza7
            // 
            this.lblPizza7.AutoSize = true;
            this.lblPizza7.Location = new System.Drawing.Point(23, 219);
            this.lblPizza7.Name = "lblPizza7";
            this.lblPizza7.Size = new System.Drawing.Size(87, 13);
            this.lblPizza7.TabIndex = 51;
            this.lblPizza7.Text = "Salaatti (10,00 €)";
            // 
            // lblPizza8
            // 
            this.lblPizza8.AutoSize = true;
            this.lblPizza8.Location = new System.Drawing.Point(23, 245);
            this.lblPizza8.Name = "lblPizza8";
            this.lblPizza8.Size = new System.Drawing.Size(102, 13);
            this.lblPizza8.TabIndex = 52;
            this.lblPizza8.Text = "Americano (10,00 €)";
            // 
            // lblPizza9
            // 
            this.lblPizza9.AutoSize = true;
            this.lblPizza9.Location = new System.Drawing.Point(23, 271);
            this.lblPizza9.Name = "lblPizza9";
            this.lblPizza9.Size = new System.Drawing.Size(92, 13);
            this.lblPizza9.TabIndex = 53;
            this.lblPizza9.Text = "Fantasia (10,00 €)";
            // 
            // lblPizza10
            // 
            this.lblPizza10.AutoSize = true;
            this.lblPizza10.Location = new System.Drawing.Point(23, 297);
            this.lblPizza10.Name = "lblPizza10";
            this.lblPizza10.Size = new System.Drawing.Size(91, 13);
            this.lblPizza10.TabIndex = 54;
            this.lblPizza10.Text = "Chicken (10,00 €)";
            // 
            // txtTulostus
            // 
            this.txtTulostus.Location = new System.Drawing.Point(191, 377);
            this.txtTulostus.Multiline = true;
            this.txtTulostus.Name = "txtTulostus";
            this.txtTulostus.ReadOnly = true;
            this.txtTulostus.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTulostus.Size = new System.Drawing.Size(250, 275);
            this.txtTulostus.TabIndex = 55;
            // 
            // btnLaske
            // 
            this.btnLaske.Location = new System.Drawing.Point(26, 377);
            this.btnLaske.Name = "btnLaske";
            this.btnLaske.Size = new System.Drawing.Size(75, 23);
            this.btnLaske.TabIndex = 56;
            this.btnLaske.Text = "Laske";
            this.btnLaske.UseVisualStyleBackColor = true;
            this.btnLaske.Click += new System.EventHandler(this.btnLaske_Click);
            // 
            // btnTyhjenna
            // 
            this.btnTyhjenna.Location = new System.Drawing.Point(26, 453);
            this.btnTyhjenna.Name = "btnTyhjenna";
            this.btnTyhjenna.Size = new System.Drawing.Size(75, 23);
            this.btnTyhjenna.TabIndex = 57;
            this.btnTyhjenna.Text = "Tyhjennä";
            this.btnTyhjenna.UseVisualStyleBackColor = true;
            this.btnTyhjenna.Click += new System.EventHandler(this.btnTyhjenna_Click);
            // 
            // btnKassa
            // 
            this.btnKassa.Location = new System.Drawing.Point(26, 415);
            this.btnKassa.Name = "btnKassa";
            this.btnKassa.Size = new System.Drawing.Size(75, 23);
            this.btnKassa.TabIndex = 58;
            this.btnKassa.Text = "Kassa";
            this.btnKassa.UseVisualStyleBackColor = true;
            this.btnKassa.Click += new System.EventHandler(this.btnKassa_Click);
            // 
            // txtKassaTulostus
            // 
            this.txtKassaTulostus.Location = new System.Drawing.Point(470, 377);
            this.txtKassaTulostus.Multiline = true;
            this.txtKassaTulostus.Name = "txtKassaTulostus";
            this.txtKassaTulostus.ReadOnly = true;
            this.txtKassaTulostus.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtKassaTulostus.Size = new System.Drawing.Size(250, 275);
            this.txtKassaTulostus.TabIndex = 59;
            // 
            // lblTulostus
            // 
            this.lblTulostus.AutoSize = true;
            this.lblTulostus.Location = new System.Drawing.Point(188, 352);
            this.lblTulostus.Name = "lblTulostus";
            this.lblTulostus.Size = new System.Drawing.Size(115, 13);
            this.lblTulostus.TabIndex = 60;
            this.lblTulostus.Text = "Kokonaiskustannukset";
            // 
            // lblKassaTulostus
            // 
            this.lblKassaTulostus.AutoSize = true;
            this.lblKassaTulostus.Location = new System.Drawing.Point(467, 352);
            this.lblKassaTulostus.Name = "lblKassaTulostus";
            this.lblKassaTulostus.Size = new System.Drawing.Size(112, 13);
            this.lblKassaTulostus.TabIndex = 61;
            this.lblKassaTulostus.Text = "Kassaan kertynyt raha";
            // 
            // numUpDown05L
            // 
            this.numUpDown05L.Location = new System.Drawing.Point(419, 63);
            this.numUpDown05L.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDown05L.Name = "numUpDown05L";
            this.numUpDown05L.Size = new System.Drawing.Size(39, 20);
            this.numUpDown05L.TabIndex = 62;
            // 
            // numUpDown15L
            // 
            this.numUpDown15L.Location = new System.Drawing.Point(419, 93);
            this.numUpDown15L.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numUpDown15L.Name = "numUpDown15L";
            this.numUpDown15L.Size = new System.Drawing.Size(39, 20);
            this.numUpDown15L.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(346, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 68;
            this.label1.Text = "0,5L (3,00 €)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(346, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 69;
            this.label2.Text = "1,5L (5,00 €)";
            // 
            // btnMuutaHintoja
            // 
            this.btnMuutaHintoja.Location = new System.Drawing.Point(26, 673);
            this.btnMuutaHintoja.Name = "btnMuutaHintoja";
            this.btnMuutaHintoja.Size = new System.Drawing.Size(108, 23);
            this.btnMuutaHintoja.TabIndex = 70;
            this.btnMuutaHintoja.Text = "Muuta hintoja";
            this.btnMuutaHintoja.UseVisualStyleBackColor = true;
            this.btnMuutaHintoja.Click += new System.EventHandler(this.btnMuutaHintoja_Click);
            // 
            // lblPizza1Uusi
            // 
            this.lblPizza1Uusi.AutoSize = true;
            this.lblPizza1Uusi.Location = new System.Drawing.Point(188, 673);
            this.lblPizza1Uusi.Name = "lblPizza1Uusi";
            this.lblPizza1Uusi.Size = new System.Drawing.Size(141, 13);
            this.lblPizza1Uusi.TabIndex = 71;
            this.lblPizza1Uusi.Text = "Pepperoni uusi hinta euroina";
            // 
            // numUpDownPizza1Uusi
            // 
            this.numUpDownPizza1Uusi.Location = new System.Drawing.Point(344, 673);
            this.numUpDownPizza1Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza1Uusi.Name = "numUpDownPizza1Uusi";
            this.numUpDownPizza1Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza1Uusi.TabIndex = 72;
            // 
            // numUpDownPizza2Uusi
            // 
            this.numUpDownPizza2Uusi.Location = new System.Drawing.Point(344, 695);
            this.numUpDownPizza2Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza2Uusi.Name = "numUpDownPizza2Uusi";
            this.numUpDownPizza2Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza2Uusi.TabIndex = 74;
            // 
            // lblPizza2Uusi
            // 
            this.lblPizza2Uusi.AutoSize = true;
            this.lblPizza2Uusi.Location = new System.Drawing.Point(188, 695);
            this.lblPizza2Uusi.Name = "lblPizza2Uusi";
            this.lblPizza2Uusi.Size = new System.Drawing.Size(125, 13);
            this.lblPizza2Uusi.TabIndex = 73;
            this.lblPizza2Uusi.Text = "Havaiji uusi hinta euroina";
            // 
            // lblPizza3Uusi
            // 
            this.lblPizza3Uusi.AutoSize = true;
            this.lblPizza3Uusi.Location = new System.Drawing.Point(188, 717);
            this.lblPizza3Uusi.Name = "lblPizza3Uusi";
            this.lblPizza3Uusi.Size = new System.Drawing.Size(148, 13);
            this.lblPizza3Uusi.TabIndex = 75;
            this.lblPizza3Uusi.Text = "Capricciosa uusi hinta euroina";
            // 
            // lblPizza4Uusi
            // 
            this.lblPizza4Uusi.AutoSize = true;
            this.lblPizza4Uusi.Location = new System.Drawing.Point(188, 739);
            this.lblPizza4Uusi.Name = "lblPizza4Uusi";
            this.lblPizza4Uusi.Size = new System.Drawing.Size(143, 13);
            this.lblPizza4Uusi.TabIndex = 76;
            this.lblPizza4Uusi.Text = "Margherita uusi hinta euroina";
            // 
            // lblPizza5Uusi
            // 
            this.lblPizza5Uusi.AutoSize = true;
            this.lblPizza5Uusi.Location = new System.Drawing.Point(188, 761);
            this.lblPizza5Uusi.Name = "lblPizza5Uusi";
            this.lblPizza5Uusi.Size = new System.Drawing.Size(124, 13);
            this.lblPizza5Uusi.TabIndex = 77;
            this.lblPizza5Uusi.Text = "Kebab uusi hinta euroina";
            // 
            // lblPizza6Uusi
            // 
            this.lblPizza6Uusi.AutoSize = true;
            this.lblPizza6Uusi.Location = new System.Drawing.Point(188, 783);
            this.lblPizza6Uusi.Name = "lblPizza6Uusi";
            this.lblPizza6Uusi.Size = new System.Drawing.Size(139, 13);
            this.lblPizza6Uusi.TabIndex = 78;
            this.lblPizza6Uusi.Text = "Mexicana uusi hinta euroina";
            // 
            // lblPizza7Uusi
            // 
            this.lblPizza7Uusi.AutoSize = true;
            this.lblPizza7Uusi.Location = new System.Drawing.Point(188, 805);
            this.lblPizza7Uusi.Name = "lblPizza7Uusi";
            this.lblPizza7Uusi.Size = new System.Drawing.Size(128, 13);
            this.lblPizza7Uusi.TabIndex = 79;
            this.lblPizza7Uusi.Text = "Salaatti uusi hinta euroina";
            // 
            // lblPizza8Uusi
            // 
            this.lblPizza8Uusi.AutoSize = true;
            this.lblPizza8Uusi.Location = new System.Drawing.Point(188, 827);
            this.lblPizza8Uusi.Name = "lblPizza8Uusi";
            this.lblPizza8Uusi.Size = new System.Drawing.Size(143, 13);
            this.lblPizza8Uusi.TabIndex = 80;
            this.lblPizza8Uusi.Text = "Americano uusi hinta euroina";
            // 
            // lblPizza9Uusi
            // 
            this.lblPizza9Uusi.AutoSize = true;
            this.lblPizza9Uusi.Location = new System.Drawing.Point(188, 849);
            this.lblPizza9Uusi.Name = "lblPizza9Uusi";
            this.lblPizza9Uusi.Size = new System.Drawing.Size(133, 13);
            this.lblPizza9Uusi.TabIndex = 81;
            this.lblPizza9Uusi.Text = "Fantasia uusi hinta euroina";
            // 
            // lblPizza10Uusi
            // 
            this.lblPizza10Uusi.AutoSize = true;
            this.lblPizza10Uusi.Location = new System.Drawing.Point(188, 871);
            this.lblPizza10Uusi.Name = "lblPizza10Uusi";
            this.lblPizza10Uusi.Size = new System.Drawing.Size(132, 13);
            this.lblPizza10Uusi.TabIndex = 82;
            this.lblPizza10Uusi.Text = "Chicken uusi hinta euroina";
            // 
            // numUpDownPizza3Uusi
            // 
            this.numUpDownPizza3Uusi.Location = new System.Drawing.Point(344, 717);
            this.numUpDownPizza3Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza3Uusi.Name = "numUpDownPizza3Uusi";
            this.numUpDownPizza3Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza3Uusi.TabIndex = 83;
            // 
            // numUpDownPizza4Uusi
            // 
            this.numUpDownPizza4Uusi.Location = new System.Drawing.Point(344, 739);
            this.numUpDownPizza4Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza4Uusi.Name = "numUpDownPizza4Uusi";
            this.numUpDownPizza4Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza4Uusi.TabIndex = 84;
            // 
            // numUpDownPizza5Uusi
            // 
            this.numUpDownPizza5Uusi.Location = new System.Drawing.Point(344, 761);
            this.numUpDownPizza5Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza5Uusi.Name = "numUpDownPizza5Uusi";
            this.numUpDownPizza5Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza5Uusi.TabIndex = 85;
            // 
            // numUpDownPizza6Uusi
            // 
            this.numUpDownPizza6Uusi.Location = new System.Drawing.Point(344, 783);
            this.numUpDownPizza6Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza6Uusi.Name = "numUpDownPizza6Uusi";
            this.numUpDownPizza6Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza6Uusi.TabIndex = 86;
            // 
            // numUpDownPizza7Uusi
            // 
            this.numUpDownPizza7Uusi.Location = new System.Drawing.Point(344, 805);
            this.numUpDownPizza7Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza7Uusi.Name = "numUpDownPizza7Uusi";
            this.numUpDownPizza7Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza7Uusi.TabIndex = 87;
            // 
            // numUpDownPizza8Uusi
            // 
            this.numUpDownPizza8Uusi.Location = new System.Drawing.Point(344, 827);
            this.numUpDownPizza8Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza8Uusi.Name = "numUpDownPizza8Uusi";
            this.numUpDownPizza8Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza8Uusi.TabIndex = 88;
            // 
            // numUpDownPizza9Uusi
            // 
            this.numUpDownPizza9Uusi.Location = new System.Drawing.Point(344, 849);
            this.numUpDownPizza9Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza9Uusi.Name = "numUpDownPizza9Uusi";
            this.numUpDownPizza9Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza9Uusi.TabIndex = 89;
            // 
            // numUpDownPizza10Uusi
            // 
            this.numUpDownPizza10Uusi.Location = new System.Drawing.Point(344, 871);
            this.numUpDownPizza10Uusi.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numUpDownPizza10Uusi.Name = "numUpDownPizza10Uusi";
            this.numUpDownPizza10Uusi.Size = new System.Drawing.Size(39, 20);
            this.numUpDownPizza10Uusi.TabIndex = 90;
            // 
            // btnTallennaUudetHinnat
            // 
            this.btnTallennaUudetHinnat.Location = new System.Drawing.Point(470, 868);
            this.btnTallennaUudetHinnat.Name = "btnTallennaUudetHinnat";
            this.btnTallennaUudetHinnat.Size = new System.Drawing.Size(142, 23);
            this.btnTallennaUudetHinnat.TabIndex = 91;
            this.btnTallennaUudetHinnat.Text = "Tallenna Uudet Hinnat";
            this.btnTallennaUudetHinnat.UseVisualStyleBackColor = true;
            this.btnTallennaUudetHinnat.Click += new System.EventHandler(this.btnTallennaUudetHinnat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 936);
            this.Controls.Add(this.btnTallennaUudetHinnat);
            this.Controls.Add(this.numUpDownPizza10Uusi);
            this.Controls.Add(this.numUpDownPizza9Uusi);
            this.Controls.Add(this.numUpDownPizza8Uusi);
            this.Controls.Add(this.numUpDownPizza7Uusi);
            this.Controls.Add(this.numUpDownPizza6Uusi);
            this.Controls.Add(this.numUpDownPizza5Uusi);
            this.Controls.Add(this.numUpDownPizza4Uusi);
            this.Controls.Add(this.numUpDownPizza3Uusi);
            this.Controls.Add(this.lblPizza10Uusi);
            this.Controls.Add(this.lblPizza9Uusi);
            this.Controls.Add(this.lblPizza8Uusi);
            this.Controls.Add(this.lblPizza7Uusi);
            this.Controls.Add(this.lblPizza6Uusi);
            this.Controls.Add(this.lblPizza5Uusi);
            this.Controls.Add(this.lblPizza4Uusi);
            this.Controls.Add(this.lblPizza3Uusi);
            this.Controls.Add(this.numUpDownPizza2Uusi);
            this.Controls.Add(this.lblPizza2Uusi);
            this.Controls.Add(this.numUpDownPizza1Uusi);
            this.Controls.Add(this.lblPizza1Uusi);
            this.Controls.Add(this.btnMuutaHintoja);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numUpDown15L);
            this.Controls.Add(this.numUpDown05L);
            this.Controls.Add(this.lblKassaTulostus);
            this.Controls.Add(this.lblTulostus);
            this.Controls.Add(this.txtKassaTulostus);
            this.Controls.Add(this.btnKassa);
            this.Controls.Add(this.btnTyhjenna);
            this.Controls.Add(this.btnLaske);
            this.Controls.Add(this.txtTulostus);
            this.Controls.Add(this.lblPizza10);
            this.Controls.Add(this.lblPizza9);
            this.Controls.Add(this.lblPizza8);
            this.Controls.Add(this.lblPizza7);
            this.Controls.Add(this.lblPizza6);
            this.Controls.Add(this.lblPizza5);
            this.Controls.Add(this.lblPizza4);
            this.Controls.Add(this.lblPizza3);
            this.Controls.Add(this.lblPizza2);
            this.Controls.Add(this.lblValitseJuomat);
            this.Controls.Add(this.lblValitseLisataytteet);
            this.Controls.Add(this.lblValitsePizzat);
            this.Controls.Add(this.numUpDownLisataytteet10);
            this.Controls.Add(this.numUpDownLisataytteet9);
            this.Controls.Add(this.numUpDownLisataytteet8);
            this.Controls.Add(this.numUpDownLisataytteet7);
            this.Controls.Add(this.numUpDownLisataytteet6);
            this.Controls.Add(this.numUpDownLisataytteet5);
            this.Controls.Add(this.numUpDownLisataytteet4);
            this.Controls.Add(this.numUpDownLisataytteet3);
            this.Controls.Add(this.numUpDownLisataytteet2);
            this.Controls.Add(this.numUpDownLisataytteet1);
            this.Controls.Add(this.numUpDownPizza10);
            this.Controls.Add(this.numUpDownPizza9);
            this.Controls.Add(this.numUpDownPizza8);
            this.Controls.Add(this.numUpDownPizza7);
            this.Controls.Add(this.numUpDownPizza6);
            this.Controls.Add(this.numUpDownPizza5);
            this.Controls.Add(this.numUpDownPizza4);
            this.Controls.Add(this.numUpDownPizza3);
            this.Controls.Add(this.numUpDownPizza2);
            this.Controls.Add(this.numUpDownPizza1);
            this.Controls.Add(this.lblPizza1);
            this.Name = "Form1";
            this.Text = "C# Koe";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownLisataytteet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown05L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDown15L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza1Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza2Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza3Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza4Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza5Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza6Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza7Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza8Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza9Uusi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownPizza10Uusi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPizza1;
        private System.Windows.Forms.NumericUpDown numUpDownPizza1;
        private System.Windows.Forms.NumericUpDown numUpDownPizza2;
        private System.Windows.Forms.NumericUpDown numUpDownPizza3;
        private System.Windows.Forms.NumericUpDown numUpDownPizza4;
        private System.Windows.Forms.NumericUpDown numUpDownPizza5;
        private System.Windows.Forms.NumericUpDown numUpDownPizza6;
        private System.Windows.Forms.NumericUpDown numUpDownPizza7;
        private System.Windows.Forms.NumericUpDown numUpDownPizza8;
        private System.Windows.Forms.NumericUpDown numUpDownPizza9;
        private System.Windows.Forms.NumericUpDown numUpDownPizza10;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet10;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet9;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet8;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet7;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet6;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet5;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet4;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet3;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet2;
        private System.Windows.Forms.NumericUpDown numUpDownLisataytteet1;
        private System.Windows.Forms.Label lblValitsePizzat;
        private System.Windows.Forms.Label lblValitseLisataytteet;
        private System.Windows.Forms.Label lblValitseJuomat;
        private System.Windows.Forms.Label lblPizza2;
        private System.Windows.Forms.Label lblPizza3;
        private System.Windows.Forms.Label lblPizza4;
        private System.Windows.Forms.Label lblPizza5;
        private System.Windows.Forms.Label lblPizza6;
        private System.Windows.Forms.Label lblPizza7;
        private System.Windows.Forms.Label lblPizza8;
        private System.Windows.Forms.Label lblPizza9;
        private System.Windows.Forms.Label lblPizza10;
        private System.Windows.Forms.TextBox txtTulostus;
        private System.Windows.Forms.Button btnLaske;
        private System.Windows.Forms.Button btnTyhjenna;
        private System.Windows.Forms.Button btnKassa;
        private System.Windows.Forms.TextBox txtKassaTulostus;
        private System.Windows.Forms.Label lblTulostus;
        private System.Windows.Forms.Label lblKassaTulostus;
        private System.Windows.Forms.NumericUpDown numUpDown05L;
        private System.Windows.Forms.NumericUpDown numUpDown15L;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMuutaHintoja;
        private System.Windows.Forms.Label lblPizza1Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza1Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza2Uusi;
        private System.Windows.Forms.Label lblPizza2Uusi;
        private System.Windows.Forms.Label lblPizza3Uusi;
        private System.Windows.Forms.Label lblPizza4Uusi;
        private System.Windows.Forms.Label lblPizza5Uusi;
        private System.Windows.Forms.Label lblPizza6Uusi;
        private System.Windows.Forms.Label lblPizza7Uusi;
        private System.Windows.Forms.Label lblPizza8Uusi;
        private System.Windows.Forms.Label lblPizza9Uusi;
        private System.Windows.Forms.Label lblPizza10Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza3Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza4Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza5Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza6Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza7Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza8Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza9Uusi;
        private System.Windows.Forms.NumericUpDown numUpDownPizza10Uusi;
        private System.Windows.Forms.Button btnTallennaUudetHinnat;
    }
}

